﻿<?php 
   require ("db.php");
   
   	$result = mysql_query(" SELECT * FROM Zakaz 
	                        ORDER BY id ASC");
	
	$id = $_REQUEST['id'];
	$Name = $_REQUEST['Name'];
	$Fam = $_REQUEST['Fam'];
	$Email = $_REQUEST['Email'];
	$Tovar = $_REQUEST['Tovar'];
	$Col = $_REQUEST['Col'];
   
   	while ($row = mysql_fetch_array($result)){
	
	echo $row['id'].'<br>',
	     $row['Name'].'<br>',
         $row['Fam'].'<br>',
         $row['Email'].'<br>',
         $row['Tovar'].'<br>',
         $row['Col'].'<br>';
	}
?>