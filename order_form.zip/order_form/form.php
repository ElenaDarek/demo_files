<html>
<head>
<meta charset='utf-8'>
<title>php 9 form</title>
</head>
<body>

<form action="action.php" method="post" name="form" target="_blank" width='500'> 
<input name="id" type="text">id<br>
<input name="Name" type="text">Имя заказчика<br>
<input name="Fam" type="text">Фамилия заказчика<br>
<input name="Email" type="text">e-mail заказчика<br>
<input name="Tovar" type="text">Название товара<br>
<input name="Col" type="text">Количество штук<br>
<br>
<input name="select" type="submit" value="Выбрать"> 
</form>

<?php 
    include_once ("db.php");
	
	if (isset ($_POST['select']))
	{	
	$id = strip_tags(trim($_POST['id']));
	$Name = strip_tags(trim($_POST['Name']));
	$Fam = strip_tags(trim($_POST['Fam']));
	$Email = strip_tags(trim($_POST['Email']));
	$Tovar = strip_tags(trim($_POST['Tovar']));
	$Col = strip_tags(trim($_POST['Col']));
	
	
	$result = mysql_query(" INSERT INTO Zakaz('id','Name','Fam','Email','Tovar','Col')
                         	VALUES ('$id','$Name','$Fam','$Email','$Tovar','$Col')");
							
	echo "Ваш заказ принят";						
	
		
    mysql_close();
	}
?>



</body>
</html>