<?php 
   $connection = mysql_connect ("localhost","admin_newdb","admin123");
   $db = mysql_select_db ("NewDatabase");
   mysql_set_charset("utf-8");
 
    if (!$connection || !$db)
	{
	    exit(mysql_error ()); 
    }
?>