<html>
<head>
<meta charset='utf-8'>
<title>php 9 action</title>
</head>
<body>

<a href="zakaz.php">Посмотреть все заказы</a>

<?php 
    require ("db.php");

	$result = mysql_query(" SELECT * FROM Zakaz 
	                        ORDER BY id ASC");
	
	$id = $_REQUEST['id'];
	$Name = $_REQUEST['Name'];
	$Fam = $_REQUEST['Fam'];
	$Email = $_REQUEST['Email'];
	$Tovar = $_REQUEST['Tovar'];
	$Col = $_REQUEST['Col'];
	
	$insert_sql = "INSERT INTO Zakaz (id, Name, Fam, Email,Tovar,Col)" .
                  "VALUES('{$id}', '{$Name}', '{$Fam}', '{$Email}', '{$ETovar}','{$Col}');";
    
	mysql_query($insert_sql);	
		
    mysql_close();
?>


 
</body>
</html>